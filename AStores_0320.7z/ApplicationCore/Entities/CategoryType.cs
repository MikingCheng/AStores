﻿namespace ApplicationCore.Entities
{
  public class FM_ProductCarategory : BaseEntity
  {
    public string F_FullName { get; set; }
  }
}
