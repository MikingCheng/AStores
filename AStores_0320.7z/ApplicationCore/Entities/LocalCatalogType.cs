﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationCore.Entities
{
    public class LocalCatalogType : BaseEntity
    {
        public string F_FullName { get; set; }
    }
}
