﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationCore.Entities
{
  public class PaymentMethod : BaseEntity
  {
    public string F_PaymentName { get; set; }
    public List<SalesOrder> SalesOrders { get; set; }
  }
}
